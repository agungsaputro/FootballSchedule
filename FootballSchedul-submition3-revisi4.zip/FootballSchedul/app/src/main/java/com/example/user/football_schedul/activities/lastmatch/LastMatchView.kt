package com.example.user.football_schedul.activities.lastmatch

import com.example.user.football_schedul.model.MatchEvent

interface LastMatchView {
    interface View{
        fun hideLoading()
        fun showLoading()
        fun displayFootballMatch(matchList:List<MatchEvent>)

    }

    interface Presenter{
        fun getFootballData()

    }
}