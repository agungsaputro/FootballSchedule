@file:Suppress("Annotator")

package com.example.user.football_schedul.activities.main

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.user.football_schedul.R
import com.example.user.football_schedul.activities.favorite.FavoriteMatchFragment
import com.example.user.football_schedul.activities.lastmatch.LastMatchFragment
import com.example.user.football_schedul.activities.nextmatch.NextMatchFragment
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bottom_navigation.setOnNavigationItemReselectedListener { item ->
            when(item.itemId){
                R.id.lastMatch ->{
                    loadLastMatch(savedInstanceState)
                }
                R.id.nextMatch ->{
                    loadNextMatch(savedInstanceState)
                }
                R.id.favMatch->{
                    loadFavoritesMatch(savedInstanceState)
                }
            }
            true
        }
        bottom_navigation.selectedItemId = R.id.lastMatch
    }

    private fun loadLastMatch(savedInstanceState: Bundle?){
        if (savedInstanceState == null){
            supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.main_container, LastMatchFragment(), LastMatchFragment::class.java.simpleName)
                    .commit()
        }
    }

    private fun loadNextMatch(savedInstanceState: Bundle?){
        if (savedInstanceState == null){
            supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.main_container, NextMatchFragment(), NextMatchFragment::class.java.simpleName)
                    .commit()
        }
    }

    private fun loadFavoritesMatch(savedInstanceState: Bundle?){
        if (savedInstanceState == null){
            supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.main_container, FavoriteMatchFragment(), FavoriteMatchFragment::class.java.simpleName)
                    .commit()
        }
    }
}
