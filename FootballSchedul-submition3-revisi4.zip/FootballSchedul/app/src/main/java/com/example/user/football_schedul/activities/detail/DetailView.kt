package com.example.user.football_schedul.activities.detail

import com.example.user.football_schedul.db.FavoriteMatch
import com.example.user.football_schedul.model.Teams


interface DetailView{
    interface View{
        fun displayTeamBadgeHome(team: Teams)
        fun setFavoriteState(favList: List<FavoriteMatch>)
        fun displayTeamBadgeAway(team: Teams)
    }
    interface Presenter{
        fun getTeamBadgeHome(id: String)
        fun getTeamBadgeAway(id: String)
        fun deleteMatch(id: String)
        fun insertMatch(eventId: String, homeId: String, awayId: String)
        fun checkMatch( id: String)
    }
}