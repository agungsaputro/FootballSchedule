package com.example.user.football_schedul.utils


import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class AppSchedulerProvider : SchedulerProviderView{
    override fun ui() = AndroidSchedulers.mainThread()
    override fun io() = Schedulers.io()
}

class TrampolineSchedulerProvide : SchedulerProviderView{
    override fun ui() = Schedulers.trampoline()
    override fun io() = Schedulers.trampoline()
}