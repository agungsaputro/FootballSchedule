package com.example.user.football_schedul.utils

import android.view.View

fun View.hide(){
    visibility = View.VISIBLE
}
fun View.show(){
    visibility= View.INVISIBLE
}