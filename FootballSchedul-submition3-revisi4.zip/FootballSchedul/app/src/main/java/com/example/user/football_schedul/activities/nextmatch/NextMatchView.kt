package com.example.user.football_schedul.activities.nextmatch

import com.example.user.football_schedul.model.MatchEvent

interface NextMatchView {
    interface View{
        fun hideLoading()
        fun showLoading()
        fun displayFootballMatch(matchList:List<MatchEvent>)

    }

    interface Presenter{
        fun getFootballUpcomingData()

    }
}