package com.example.user.football_schedul.model

import com.google.gson.annotations.SerializedName

data class TeamsResponse(
        @SerializedName("teams")
        var teams: List<Teams>
)