package com.example.user.football_schedul.api

import com.example.user.football_schedul.model.MatchEventResponse
import com.example.user.football_schedul.model.TeamsResponse
import io.reactivex.Flowable
import retrofit2.http.GET
import retrofit2.http.Query

interface TheSportDBRest{
    @GET("eventspastleague.php")
    fun getLastMatch(@Query("id")id:String): Flowable<MatchEventResponse>

    @GET("eventsnextleague.php")
    fun getUpcomingMatch(@Query("id")id: String): Flowable<MatchEventResponse>

    @GET("lookupteam.php")
    fun getTeam(@Query("id") id: String): Flowable<TeamsResponse>

    @GET("lookupevent.php")
    fun getEventById(@Query("id") id:String) : Flowable<MatchEventResponse>
}