@file:Suppress("Annotator")

package com.example.user.football_schedul.activities.favorite

import com.example.user.football_schedul.model.MatchEvent
import com.example.user.football_schedul.model.MatchEventPresenter
import com.example.user.football_schedul.model.RepositoryPresenter
import com.example.user.football_schedul.utils.AppSchedulerProvider
import io.reactivex.disposables.CompositeDisposable

class FavoriteMatchPresenter(private val mView: FavoriteMatchView.View,
                             private val matchPresenter: MatchEventPresenter,
                             private val repositoryPresenter: RepositoryPresenter,
                             private val appSchedulerProvider: AppSchedulerProvider): FavoriteMatchView.Presenter{

    override fun getFootbalMatchData() {
        val compositeDisposable = CompositeDisposable()
        mView.showLoading()
        val favoriteList = repositoryPresenter.getMatchFromDb()

        val eventList: MutableList<MatchEvent> = mutableListOf()
        for (fav in favoriteList){
            compositeDisposable.add(matchPresenter.getEventById(fav.idEvent)
                    .observeOn(appSchedulerProvider.ui())
                    .subscribeOn(appSchedulerProvider.io())
                    .subscribe{
                        eventList.add(it.events[0])
                        mView.displayFootballMatch(eventList)
                        mView.hideLoading()
                        mView.hideSwipeRefresh()
                    })
        }
        if (favoriteList.isEmpty()){
            mView.hideLoading()
            mView.displayFootballMatch(eventList)
            mView.hideSwipeRefresh()
        }
    }
}