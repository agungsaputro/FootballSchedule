package com.example.user.football_schedul.model

import com.example.user.football_schedul.api.TheSportDBRest
import io.reactivex.Flowable

class MatchEventPresenter( private val theSportDBRest: TheSportDBRest): MatchEventView{
    override fun getUpcomingMatch(id: String): Flowable<MatchEventResponse> = theSportDBRest.getUpcomingMatch(id)
    override fun getFootballMatch(id: String): Flowable<MatchEventResponse> = theSportDBRest.getLastMatch(id)
    override fun getTeams(id: String): Flowable<TeamsResponse> = theSportDBRest.getTeam(id)
    fun getEventById(id: String): Flowable<MatchEventResponse> = theSportDBRest.getEventById(id)
}