package com.example.user.football_schedul.activities.lastmatch

import com.example.user.football_schedul.model.MatchEventPresenter
import com.example.user.football_schedul.utils.SchedulerProviderView
import io.reactivex.disposables.CompositeDisposable


class LastMatchPresenter( private val mView: LastMatchView.View, private val matchEventPresenter: MatchEventPresenter,
                          private val appSchedulerProvider: SchedulerProviderView) : LastMatchView.Presenter{
    private val compositeDisposable = CompositeDisposable()

    override fun getFootballData() {
        mView.showLoading()
        compositeDisposable.add(matchEventPresenter.getFootballMatch("4332")
                .observeOn(appSchedulerProvider.ui())
                .subscribeOn(appSchedulerProvider.io())
                .subscribe{
                    mView.displayFootballMatch(it.events)
                    mView.hideLoading()
                })
    }
}