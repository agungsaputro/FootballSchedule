package com.example.user.football_schedul.activities.favorite

import com.example.user.football_schedul.model.MatchEvent

interface FavoriteMatchView{
    interface View{
        fun hideLoading()
        fun showLoading()
        fun displayFootballMatch(matchList: List<MatchEvent>)
        fun hideSwipeRefresh()

    }

    interface Presenter{
        fun getFootbalMatchData()
    }
}