package com.example.user.football_schedul.model

import com.example.user.football_schedul.db.FavoriteMatch

interface Repository{
    fun getMatchFromDb() : List<FavoriteMatch>
    fun insertData(eventId: String, homeId: String, awayId: String)
    fun deleteData(eventId: String)
    fun checkFavorite(eventId: String) : List<FavoriteMatch>
}