package com.example.user.football_schedul.utils

import io.reactivex.Scheduler

interface SchedulerProviderView{
    fun ui(): Scheduler
    fun io(): Scheduler
}